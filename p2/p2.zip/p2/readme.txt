./suffix input alpha

topresult contains top command result at the at of tree construction for Three DNA sequence input

output contains following information for each input
	sequence length 
	alpha 	 length
	Build Tree Time
 	Tree information #internal , #leaves , #total , size 
	post-order traversal depths (for s1 s2 only)
	DFS depths		    (for s1 s2 only)
	avg internal depth: , max internal depth: 
	longest exact matching sequence is at node id :
	longest exact matching sequence
	longest exact matching sequence suffix id
